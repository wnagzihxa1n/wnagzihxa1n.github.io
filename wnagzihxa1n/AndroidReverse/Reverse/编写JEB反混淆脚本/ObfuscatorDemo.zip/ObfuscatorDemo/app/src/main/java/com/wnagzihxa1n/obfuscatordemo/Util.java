package com.wnagzihxa1n.obfuscatordemo;

public class Util {

    public static String decStr(byte[] data) {
        return new String(data);
    }
}
