package com.wnagzihxa1n.obfuscatordemo;

import android.app.Activity;
import android.util.Log;

public class Activity03 extends Activity {
    public static void funcC() {
        Log.i("toT0C", Util.decStr(new byte[]{0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33}));//3333333333
    }
}
