package com.wnagzihxa1n.obfuscatordemo;

import android.app.Activity;
import android.util.Log;

public class Activity05 extends Activity {
    public static void funcE() {
        Log.i("toT0C", Util.decStr(new byte[]{0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35}));//5555555555
    }
}
