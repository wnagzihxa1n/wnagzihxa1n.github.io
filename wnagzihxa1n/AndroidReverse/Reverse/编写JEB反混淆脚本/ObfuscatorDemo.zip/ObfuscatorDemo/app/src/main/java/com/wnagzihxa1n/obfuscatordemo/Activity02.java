package com.wnagzihxa1n.obfuscatordemo;

import android.app.Activity;
import android.util.Log;

public class Activity02 extends Activity {
    public static void funcB() {
        Log.i("toT0C", Util.decStr(new byte[]{0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32}));//2222222222
    }
}
