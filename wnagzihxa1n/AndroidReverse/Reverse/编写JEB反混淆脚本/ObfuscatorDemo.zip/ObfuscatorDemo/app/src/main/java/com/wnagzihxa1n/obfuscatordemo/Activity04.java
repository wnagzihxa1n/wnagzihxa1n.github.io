package com.wnagzihxa1n.obfuscatordemo;

import android.app.Activity;
import android.util.Log;

public class Activity04 extends Activity {
    public static void funcD() {
        Log.i("toT0C", Util.decStr(new byte[]{0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34}));//4444444444
    }
}
